const express = require('express');
const router = express.Router();
const mainController = require('../controllers/mainController');

// Rute login dan register
router.get('/login', mainController.getLogin);
router.post('/login', mainController.postLogin);
router.get('/register', mainController.getRegister);
router.post('/register', mainController.postRegister);

// Rute CRUD Kapal
router.get('/kapal', mainController.getAllKapal);
router.post('/kapal/add', mainController.addKapal);
router.post('/kapal/edit/:id', mainController.editKapal);
router.post('/kapal/delete/:id', mainController.deleteKapal);

// Rute CRUD Nelayan
router.get('/nelayan', mainController.getAllNelayan);
router.post('/nelayan/add', mainController.addNelayan);
router.post('/nelayan/edit/:id', mainController.editNelayan);
router.post('/nelayan/delete/:id', mainController.deleteNelayan);

// Rute CRUD Hasil Tangkapan
router.get('/hasil', mainController.getAllHasil);
router.post('/hasil/add', mainController.addHasil);
router.post('/hasil/add', mainController.addHasil);
router.post('/hasil/edit/:id', mainController.editHasil);
router.post('/hasil/delete/:id', mainController.deleteHasil);

// Rute CRUD Jadwal Keberangkatan
router.get('/jadwal', mainController.getAllJadwal);
router.post('/jadwal/add', mainController.addJadwal);
router.post('/jadwal/edit/:id', mainController.editJadwal);
router.post('/jadwal/delete/:id', mainController.deleteJadwal);

router.get('/home', mainController.getHome); // Rute untuk homepage setelah login
router.get('/logout', mainController.logout); // Rute untuk logout

module.exports = router;
