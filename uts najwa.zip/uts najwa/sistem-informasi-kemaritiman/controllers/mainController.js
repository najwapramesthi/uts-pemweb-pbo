// controllers/mainController.js
const db = require('../config/db'); // Import koneksi database

// Metode untuk login
exports.getLogin = (req, res) => {
    res.render('auth/login'); // Tampilkan halaman login
};

exports.postLogin = (req, res) => {
    const { username, password } = req.body;
    // Logika verifikasi (misalnya menggunakan database)
    if (username && password ) { // Contoh sederhana
        req.session.user = username; // Simpan informasi user di session
        res.redirect('/mainController/kapal'); // Alihkan ke halaman kapal setelah login
    } else {
        res.redirect('/login'); // Kembali ke halaman login jika gagal
    }
};

// Metode untuk register
exports.getRegister = (req, res) => {
    res.render('auth/register'); // Tampilkan halaman register
};

exports.postRegister = (req, res) => {
    const { username, password } = req.body;
    // Logika untuk menyimpan pengguna baru ke database
    db.query('INSERT INTO users SET ?', { username, password }, (err, result) => {
        if (err) throw err;
        res.redirect('/login');
    });
};

// Metode CRUD Kapal
exports.getAllKapal = (req, res) => {
    db.query('SELECT * FROM kapal', (err, results) => {
        if (err) throw err;
        res.render('kapal/index', { kapal: results });
    });
};

exports.addKapal = (req, res) => {
    const newKapal = req.body;
    db.query('INSERT INTO kapal SET ?', newKapal, (err, result) => {
        if (err) throw err;
        res.redirect('/kapal');
    });
};

exports.editKapal = (req, res) => {
    const { id } = req.params;
    const updatedKapal = req.body;
    db.query('UPDATE kapal SET ? WHERE id = ?', [updatedKapal, id], (err, result) => {
        if (err) throw err;
        res.redirect('/kapal');
    });
};

exports.deleteKapal = (req, res) => {
    const { id } = req.params;
    db.query('DELETE FROM kapal WHERE id = ?', id, (err, result) => {
        if (err) throw err;
        res.redirect('/kapal');
    });
};

// Metode CRUD Nelayan
exports.getAllNelayan = (req, res) => {
    db.query('SELECT * FROM nelayan', (err, results) => {
        if (err) throw err;
        res.render('nelayan/index', { nelayan: results });
    });
};

exports.addNelayan = (req, res) => {
    const newNelayan = req.body;
    db.query('INSERT INTO nelayan SET ?', newNelayan, (err, result) => {
        if (err) throw err;
        res.redirect('/nelayan');
    });
};

exports.editNelayan = (req, res) => {
    const { id } = req.params;
    const updatedNelayan = req.body;
    db.query('UPDATE nelayan SET ? WHERE id = ?', [updatedNelayan, id], (err, result) => {
        if (err) throw err;
        res.redirect('/nelayan');
    });
};

exports.deleteNelayan = (req, res) => {
    const { id } = req.params;
    db.query('DELETE FROM nelayan WHERE id = ?', id, (err, result) => {
        if (err) throw err;
        res.redirect('/nelayan');
    });
};

// Metode CRUD Hasil Tangkapan
exports.getAllHasil = (req, res) => {
    // Mengambil data kapal
    db.query('SELECT * FROM kapal', (err, kapal) => {
        if (err) {
            console.error(err);
            return res.status(500).send('Error retrieving kapal data');
        }
        
        // Mengambil data hasil tangkapan
        db.query('SELECT * FROM hasil_tangkapan', (err, results) => {
            if (err) {
                console.error(err); // Log error untuk debugging
                return res.status(500).send('Error retrieving hasil data'); // Mengirimkan respons kesalahan
            }

            // Merender tampilan dengan data kapal dan hasil
            res.render('hasil/index', { hasil: results, kapal: kapal });
        });
    });
};


exports.addHasil = (req, res) => {
    const newHasil = req.body;
    db.query('INSERT INTO hasil_tangkapan SET ?', newHasil, (err, result) => {
        if (err) throw err;
        res.redirect('/hasil');
    });
};

exports.editHasil = (req, res) => {
    const { id } = req.params;
    const updatedHasil = req.body;
    db.query('UPDATE hasil_tangkapan SET ? WHERE id = ?', [updatedHasil, id], (err, result) => {
        if (err) throw err;
        res.redirect('/hasil');
    });
};

exports.deleteHasil = (req, res) => {
    const { id } = req.params;
    db.query('DELETE FROM hasil_tangkapan WHERE id = ?', id, (err, result) => {
        if (err) throw err;
        res.redirect('/hasil');
    });
};

// Metode CRUD Jadwal Keberangkatan
exports.getAllJadwal = (req, res) => {
    db.query('SELECT * FROM jadwal_keberangkatan', (err, results) => {
        if (err) throw err;
        res.render('jadwal/index', { jadwal: results });
    });
};

exports.addJadwal = (req, res) => {
    const newJadwal = req.body;
    db.query('INSERT INTO jadwal_keberangkatan SET ?', newJadwal, (err, result) => {
        if (err) throw err;
        res.redirect('/jadwal');
    });
};

exports.editJadwal = (req, res) => {
    const { id } = req.params;
    const updatedJadwal = req.body;
    db.query('UPDATE jadwal_keberangkatan SET ? WHERE id = ?', [updatedJadwal, id], (err, result) => {
        if (err) throw err;
        res.redirect('/jadwal');
    });
};

exports.deleteJadwal = (req, res) => {
    const { id } = req.params;
    db.query('DELETE FROM jadwal_keberangkatan WHERE id = ?', id, (err, result) => {
        if (err) throw err;
        res.redirect('/jadwal');
    });
};


exports.getHome = (req, res) => {
    if (req.session.user) { // Pastikan ada user yang terautentikasi
        res.render('home', { user: req.session.user }); // Kirim nama user ke tampilan
    } else {
        res.redirect('/login'); // Redirect ke login jika user belum terautentikasi
    }
};

exports.logout = (req, res) => {
    req.session.destroy(err => { // Menghapus session
        if (err) {
            console.error(err);
            return res.status(500).send('Error logging out');
        }
        res.redirect('/login'); // Redirect ke halaman login setelah logout
    });
};
