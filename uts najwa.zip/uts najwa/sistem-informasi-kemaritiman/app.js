require('dotenv').config();
const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const path = require('path');
const mainRoutes = require('./routes/mainRoutes');
const expressLayouts = require('express-ejs-layouts'); // Pastikan ini ada

const app = express();

// Middleware untuk mengurai data dari form
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Middleware untuk sesi
app.use(session({
    secret: 'secret',
    resave: false,
    saveUninitialized: true
}));

// Menggunakan express-ejs-layouts
app.use(expressLayouts); // Harus ada sebelum set view engine

// Menetapkan view engine
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');


// Menentukan layout default
app.set('layout', 'layout'); // Nama file layout tanpa ekstensi .ejs

// Menentukan folder untuk file statis
app.use(express.static(path.join(__dirname, 'public')));

// Rute default
app.get('/', (req, res) => {
    res.redirect('/login'); 
});

// Menggunakan rute auth
app.use('/', mainRoutes);

// Menjalankan server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
